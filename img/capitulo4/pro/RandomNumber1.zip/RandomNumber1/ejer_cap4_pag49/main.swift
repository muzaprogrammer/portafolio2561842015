//
//  main.swift
//  ejer_cap4_pag49
//
//  Created by Development on 3/7/21.
//  Copyright © 2021 Development. All rights reserved.
//
//
// main.swift
// Guess

import Foundation

var randomNumber = 1
var userGuess: Int? = 1
var continueGuessing = true
var keepPlaying = true
var countAdivinar : Int
func leer() -> String {
    var entrada : String
    entrada = NSString(data: FileHandle.standardInput.availableData, encoding:String.Encoding.utf8.rawValue)! as String
    entrada = entrada.replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range: nil)
    return entrada
}
while keepPlaying {
    randomNumber = Int(arc4random_uniform(101)) //get a random number between 0-100
//    print("The random number to guess is: \(randomNumber)")
    countAdivinar = 0
    while continueGuessing {
        countAdivinar += 1
//        print(randomNumber)
        print("Pick a number between 0 and 100.")
        
        userGuess = Int(leer())
        if userGuess == randomNumber {
            continueGuessing = false
            print("Correct number!")
        }
            //nested if statement
        else if userGuess! > randomNumber {
            // user guessed too high
            print("Your guess is too high")
        }
        else{
            // no reason to check if userGuess < randomNumber. It has to be.
            print("Your guess is too low")
        }
    }
    print ("El usuario utilizo \(countAdivinar) intentos para adivinar")
    print ("Play Again? Y or N")
    
    if leer() == "N" || leer() == "n" {
        keepPlaying = false
    }
    continueGuessing = true
}
