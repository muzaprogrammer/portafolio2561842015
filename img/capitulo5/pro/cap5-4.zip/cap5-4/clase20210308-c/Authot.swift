//
//  Authot.swift
//  clase20210308-c
//
//  Created by Development on 3/22/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation

class Author : PrintedMaterial {
    var nameAuthor : String = ""
    var lastNameAuthor : String = ""
    var DateOfBirth : String = ""
    var PlaceOfBirth : String = ""
    
}
