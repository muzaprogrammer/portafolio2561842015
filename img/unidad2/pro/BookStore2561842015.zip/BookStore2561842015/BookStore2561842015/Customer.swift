//
//  Customer.swift
//  BookStore2561842015
//
//  Created by Development on 3/7/21.
//  Copyright © 2021 Development. All rights reserved.
//

import UIKit

class Customer: NSObject {
    

}
