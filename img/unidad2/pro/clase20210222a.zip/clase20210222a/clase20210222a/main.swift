//
//  main.swift
//  clase20210222a
//
//  Created by Development on 2/22/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation

print("Hello, World!")

var x = 7
var y = 8
var r = x + y

print(r)


