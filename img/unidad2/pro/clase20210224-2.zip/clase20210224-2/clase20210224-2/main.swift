//
//  main.swift
//  clase20210224-2
//
//  Created by Development on 3/7/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation

print("REALIZAR OPERACIONES")


func operaciones(val1:Int, val2:Int, ope:String) -> Int {
    var resultado : Int = 0
    
    if (ope == "+") {
        resultado = val1 + val2
    } else if (ope == "-") {
        resultado = val1 - val2
    } else if (ope == "*") {
        resultado = val1 * val2
    } else if (ope == "/") {
        if (val2==0){
            resultado = 0
        } else {
            resultado = val1 / val2
        }
    }
    return resultado
}

func leer() -> String {
    var entrada : String
    entrada = NSString(data: FileHandle.standardInput.availableData, encoding:String.Encoding.utf8.rawValue)! as String
    entrada = entrada.replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range: nil)
    return entrada
}

var ciclo = true
var historico : [String]=[String]()

while ciclo {
    print("Escribe el primer numero")
    var num1 : Int = Int(leer())!
    
    print("Escribe el segundo numero")
    var num2 : Int = Int(leer())!
    
    print("Escribe la operacion (+,-,*,/)")
    var operacion : String = leer()
    
    var res : Int = operaciones(val1: num1, val2: num2, ope: operacion)
    
    print()
    var historia = "Salida: \(num1) \(operacion) \(num2) = \(res)"
    print(historia)
    historico.append(historia)
    
    print("Desea realizar otra operacion? 'y' o 'n'.")
    var input = leer()
    if input == "N" || input == "n" {
        ciclo = false
    }
}

print("Desea ver el historial? 'y' o 'n'.")
if(leer()=="y" || leer()=="Y"){
    var i = 0
    for value in historico {
        i += 1
        print ("\(i). \(value)")
    }
}

