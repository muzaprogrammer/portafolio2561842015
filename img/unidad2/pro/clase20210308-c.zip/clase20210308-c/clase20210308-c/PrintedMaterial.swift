//
//  PrintedMaterial.swift
//  clase20210308-c
//
//  Created by Development on 3/12/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation

class PrintedMaterial {
    var Tittle : String = ""
    var PublisDate : String = ""
    var PageCount : String = ""
    var Price : String = ""
    var Publisher : String = ""
    
    func accion() -> String {
        return ""
    }
}
