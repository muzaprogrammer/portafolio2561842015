//
//  Book+CoreDataClass.swift
//  BookStoreCap11
//
//  Created by Development on 5/5/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation
import CoreData

@objc(Book)
public class Book: NSManagedObject {

}
