//
//  Informacion+CoreDataClass.swift
//  parcial42561842015
//
//  Created by Development on 5/19/21.
//  Copyright © 2021 Development. All rights reserved.
//

import Foundation
import CoreData

@objc(Informacion)
public class Informacion: NSManagedObject {

}
